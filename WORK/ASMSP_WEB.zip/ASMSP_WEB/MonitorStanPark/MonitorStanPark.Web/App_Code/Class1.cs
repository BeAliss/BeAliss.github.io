﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes; 

namespace MonitorStanPark.Web.App_Code
{
    public class Class1
    {
        public string DBUser { get; set; }
        public string DBPwd { get; set; }

        public SqlConnection GetNewConnection()
        {
            var conn = new SqlConnection
            {
                ConnectionString =
                    string.Format("user id={0};password={1};", DBUser, DBPwd)
            };
            return conn;
        }

    }
}