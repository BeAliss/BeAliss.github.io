﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes; 

namespace MonitorStanPark.Web
{
    public class DB
    {     
    
        public string DBUser { get; set; }
        public string DBPwd { get; set; }

        public SqlConnection GetNewConnection()
        {
            var conn = new SqlConnection
             {
                 ConnectionString =
                     string.Format("user id={0};password={1};", DBUser, DBPwd)
             };
            return conn;
        }


        public void UserLogIn(string userName, string pcName)
        {
            using (var sqlConnection = GetNewConnection())
            {
                try
                {
                    sqlConnection.Open();
                    
                    //const string cmdText = "begin pkg_audit.user_login(phost => :phost, puser_name => :puser_name); end;";
                    //var oraCommand = new OracleCommand(cmdText, oracleConnection);

                    //oraCommand.Parameters.Add("phost", OracleDbType.Varchar2);
                    //oraCommand.Parameters["phost"].Direction = ParameterDirection.Input;
                    //oraCommand.Parameters["phost"].Value = pcName;

                    //oraCommand.Parameters.Add("puser_name", OracleDbType.Varchar2);
                    //oraCommand.Parameters["puser_name"].Direction = ParameterDirection.Input;
                    //oraCommand.Parameters["puser_name"].Value = userName;

                    //oraCommand.ExecuteNonQuery();
                }
                finally
                {
                    sqlConnection.Close();
                }
            }
        }

    }
}