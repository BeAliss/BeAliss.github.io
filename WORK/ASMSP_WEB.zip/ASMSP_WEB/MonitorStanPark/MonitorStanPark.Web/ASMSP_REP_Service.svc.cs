﻿using System;
using System.Linq;
using System.Configuration;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.Web.Configuration;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Collections.ObjectModel;
using System.Windows.Forms;

namespace MonitorStanPark.Web
{
    [ServiceContract(Namespace = "")]
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]

    public class ASMSP_REP_Service
    {
        private string connectionString = WebConfigurationManager.AppSettings["dbConnectionString"];

        [OperationContract]
        public DateTime GetServerTime()
        {
            return DateTime.Now;
        }

        // Add more operations here and mark them with [OperationContract]
        //public ObservableCollection<MachineInfo> GetMachineInfo
        [OperationContract]
        public ObservableCollection<MachineInfo>  GetMachineInfo()
        {
            var result = new ObservableCollection<MachineInfo>(); 
            int res = 0;
            string sres ="";
            sres = "before using";
            using (SqlConnection sqlConn = new SqlConnection(connectionString))
            {        
                
            try
               {
                SqlCommand sqlCommand = new SqlCommand("[dbo].[sp_GetMachinesState]", sqlConn);
                sqlCommand.CommandType = CommandType.StoredProcedure; // текст sp_executesql имя хранимки переменные
                              
                sres = "before open";
                sqlConn.Open();
                sres = "after open";
                using (SqlDataReader dr = sqlCommand.ExecuteReader())
                {
                    
                    while (dr.Read())
                    {
                        res++;                        

                        result.Add(new MachineInfo
                        {
                            IDMachine = Convert.ToInt32(dr["IDMachine"]),
                            IDMachineOut = Convert.ToInt32(dr["IDMachineOut"]),                          
                            IDModuleIO = Convert.ToInt32(dr["IDModuleIO"]),
                            IDARM = Convert.ToInt32(dr["IDARM"]),
                            Date = Convert.ToDateTime(dr["Date"]),
                            IDSCode = Convert.ToInt32(dr["IDSCode"]),
                            TabNum = Convert.ToInt32(dr["TabNum"]),
                            states = Convert.ToString(dr["states"]),
                            bcgcolor = Convert.ToInt32(dr["bcgcolor"]),
                            res1 = Convert.ToInt32(dr["res1"]),
                            res2 = Convert.ToInt32(dr["res2"]),
                            res3 = Convert.ToInt32(dr["res3"])
                        }
                        );
                    }
                    sres = res.ToString();
                }
               }
               catch 
               {
                 }
            finally
            {
                sqlConn.Close();
            }
            }
        
            
            return result;
        }

        
    }

    [DataContract]
    public struct MachineInfo
    {
        [DataMember]
        public int IDMachine; // идентификатор станка аз БД
        [DataMember]
        public int IDMachineOut; // номер станка длинный     
        [DataMember]
        public int IDModuleIO; // идентификатор модуля ввода/вывода
        [DataMember]
        public int IDARM; // идентификатор АРМа
        [DataMember]
        public DateTime? Date; // дата обновление
        [DataMember]
        public int IDSCode; // код статуса
        [DataMember]
        public int TabNum; // табельный номер 
        [DataMember]
        public string states; //  состояние станка строкой
        [DataMember]
        public int bcgcolor; // цвет
        [DataMember]
        public int res1; // 
        [DataMember]
        public int res2; //
        [DataMember]
        public int res3; //


    }
}
