﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using MenuControl;
using MonitorStanPark.ASMSP_REP;

namespace MonitorStanPark
{
    public partial class MainPage : UserControl
    {

        public double ViewBoxWidht;
        public double ViewBoxHeight;
        public string CurrentPage { get; set; }

        public MainPage()
        {   
            InitializeComponent();           

        }


        //private void MenuBarItem_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        //{
        //    MenuBarItem menuBarItem = (MenuBarItem)sender;

        //}




    }

    
}
