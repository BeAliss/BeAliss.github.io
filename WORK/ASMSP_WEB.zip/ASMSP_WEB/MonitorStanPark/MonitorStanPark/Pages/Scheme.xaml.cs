﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Navigation;
using MonitorStanPark.ASMSP_REP;
using System.Windows.Threading;
using System.Collections.ObjectModel;
using System.Windows.Data;


namespace MonitorStanPark.Pages
{
    public partial class Scheme : Page
    {
        protected ASMSP_REP_ServiceClient _serviceClient;
        private DispatcherTimer timerMachine;
        



        public Scheme()
        {
            InitializeComponent();

            
            _serviceClient = new ASMSP_REP_ServiceClient();            
            _serviceClient.GetMachineInfoCompleted += _serviceClient_GetMachineInfoCompleted;

            StartPage();

        }


        #region Таймер и загрузка данных
        private void StartPage()
        {
            timerMachine = new DispatcherTimer();
            timerMachine.Tick += timerMachine_Tick;
            timerMachine.Interval = TimeSpan.FromSeconds(5);
            timerMachine.Start();

        }
        #endregion;

        #region Timer.OnTimer
        private void timerMachine_Tick(object sender, EventArgs e)
        {
            _serviceClient.GetMachineInfoAsync(); 
        }
        #endregion;


        // Executes when the user navigates to this page.
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            //_serviceClient.GetServerTimeAsync();
            // _serviceClient.GetMachineInfoAsync(); 
            
        }




        void _serviceClient_GetServerTimeCompleted(object sender, GetServerTimeCompletedEventArgs e)
        {
            //txt.Text = e.Result.ToString();
        }

        void _serviceClient_GetMachineInfoCompleted(object sender, GetMachineInfoCompletedEventArgs e)
        {
           // var mi = e.Result;

            ObservableCollection<MachineInfo> MachineInfoList = e.Result;
            SolidColorBrush mySolidColorBrush = new SolidColorBrush();

            foreach (MachineInfo mi in MachineInfoList)
            {
                Path mObj = LayoutRoot.FindName ("s_" +  mi.vIDMachineOut.ToString()) as Path;
                
                if (mObj !=  null)
                {
                                     
                  mObj.Fill =  new SolidColorBrush (Color.FromArgb(255, 255, 255, 0));
                }
            }
//            txt.Text = mi[0].states;

        }

     



    }
}
